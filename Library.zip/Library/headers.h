#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//============================Variables===========================
char fullname[40], title[256], author[256], line[1024];
int copies;
//============================Functions.c===========================
void remove_newline(char *str);

void clear_input_buffer();

void to_lowercase(char *str);

void book_info();

void login();

void donate();

void borrow();

void retur();

void loans();

void search_b();
//============================fileIO.c==========================
int name_search(char filename[], char text[]);

void show_loans(char fullname[]);

void borrow_book_fileIO(char fullname[], char title[], char author[], int copies);

void return_book_fileIO(const char *fullname, const char *title, const char *author, int copies);

void donate_book(char filename[], char title[], char author[], int copies);

void complex_search(char filename[], char query[]);


