#include "headers.h"


//functions like remove_newline and clear_input_buffer were the only way I managed to eliminate errors when reading lines from the keyboard
//the same applies for fflush(stdin)
void remove_newline(char *str)
{
    int len = strlen(str);
    if (len > 0 && str[len - 1] == '\n') {
        str[len - 1] = '\0';
    }
}

void clear_input_buffer()
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}
//when searching books, it is useful to deal with lowercase characters only
void to_lowercase(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = tolower(str[i]);
    }
}

void book_info()
{
    //I used this quite a lot and it's much nicer to have it all in one function
    printf("Enter the title of the book: ");
    fflush(stdin);
    fgets(title, sizeof(title), stdin);
    remove_newline(title);

    printf("Enter the author of the book: ");
    fflush(stdin);
    fgets(author, sizeof(author), stdin);
    remove_newline(author);

    printf("Enter the number of copies: ");
    scanf("%d", &copies);
    getchar();
}

void login()
{
    int logged = 0;
    char surname[20], name[20];
    //surname and name are declared here because they'll never be used again because they'll be turned into the full name
    while (logged==0) {
        printf("Please log into your account\n");
        printf("Surname: ");
        scanf("%s", surname);
        printf("Name: ");
        scanf("%s", name);
        //concatenate surname and name
        strcpy(fullname, surname);
        strcat(fullname, " ");
        strcat(fullname, name);

        logged = name_search("users.csv", fullname);
        if (logged==0)
            printf("User not found. Please try again.\n");
    }
}

void donate()
{
    book_info();

    donate_book("books.csv", title, author, copies);
}
void borrow() {

    book_info();

    borrow_book_fileIO(fullname, title, author, copies);
}
void retur()
{
    book_info();

    return_book_fileIO(fullname, title, author, copies);
}
void loans()
{
    printf("Loans:\n");

    show_loans(fullname);
}
void search_b()
{
    char query[256];

    printf("Enter search text: ");
    clear_input_buffer();
    fgets(query, sizeof(query), stdin);
    remove_newline(query);

    to_lowercase(query);

    printf("\nSearch Results:\n");
    complex_search("books.csv", query);

}
