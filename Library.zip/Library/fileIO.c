#include "headers.h"

//the following function is used for login and returns 1 if the user is found, and 0 otherwise
int name_search(char filename[], char text[]) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return 0;
    }

    while (fgets(line, sizeof(line), file)) {

        line[strcspn(line, "\n")] = '\0';

        if (strcmp(line, text) == 0) {
            fclose(file);
            return 1;
        }
    }

    fclose(file);
    return 0;
}

//this function is used for displaying the loans to the user
void show_loans(char fullname[])
{
    FILE *file = fopen("loans.csv", "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    fgets(line, sizeof(line), file);//this reads the header

    while (fgets(line, sizeof(line), file)) {//goes through each line
        char *name = strtok(line, ",");
        char *title = strtok(NULL, ",");
        char *author = strtok(NULL, ",");
        int copies_borrowed = atoi(strtok(NULL, ",\n"));

        if (strcmp(name, fullname) == 0)
            printf("Name: %s\nTitle: %s\nAuthor: %s\nCopies Borrowed: %d\n\n", name, title, author, copies_borrowed);
    }

    fclose(file);
}
//In the following functions, borrow and return, temporary files were created.
//Altough they were more complicated, it was frustrating to mess up the original file and having to recreate it
void borrow_book_fileIO(char fullname[], char title[], char author[], int copies)
{
    FILE *books_file = fopen("books.csv", "r");
    if (books_file == NULL) {
        perror("Error opening books file");
        return;
    }

    int book_found = 0; // Flag to indicate if the book is found

    while (fgets(line, sizeof(line), books_file)) {
        char *token = strtok(line, ",");
        char *book_title = token;
        token = strtok(NULL, ",");
        char *book_author = token;

        if (strcmp(book_title, title) == 0 && strcmp(book_author, author) == 0) {
            book_found = 1;
            break;
        }
    }

    fclose(books_file);

    if (!book_found) {
        printf("Error: The book \"%s\" by %s does not exist in the library.\n", title, author);
        return;
    }

    FILE *loans_file = fopen("loans.csv", "a");
    if (loans_file == NULL) {
        perror("Error opening loans file");
        return;
    }

    fprintf(loans_file, "%s,%s,%s,%d\n", fullname, title, author, copies);
    fclose(loans_file);

    // creating said temporary file, which we can open in read mode, which we cannot usually do because that erases all the content of the file
    FILE *books_input = fopen("books.csv", "r");
    FILE *books_temp = fopen("temp_books.csv", "w");
    if (books_input == NULL || books_temp == NULL) {
        perror("Error opening books file or creating temporary file");
        if (books_input) fclose(books_input);
        if (books_temp) fclose(books_temp);
        return;
    }

    // Copy csv into temporary csv and updating it
    while (fgets(line, sizeof(line), books_input)) {
        char *token = strtok(line, ",");
        char *book_title = token;
        token = strtok(NULL, ",");
        char *book_author = token;
        token = strtok(NULL, ",");
        int available_copies = atoi(token);

        // here it checks for the matching book
        if (strcmp(book_title, title) == 0 && strcmp(book_author, author) == 0) {
            available_copies -= copies;
            if (available_copies < 0) {
                printf("Error: Not enough copies available to borrow.\n");
                fclose(books_input);
                fclose(books_temp);
                remove("temp_books.csv");
                return;
            }
        }

        fprintf(books_temp, "%s,%s,%d\n", book_title, book_author, available_copies);
    }

    fclose(books_input);
    fclose(books_temp);

    remove("books.csv");
    rename("temp_books.csv", "books.csv");

    printf("Successfully borrowed %d copies of \"%s\" by %s.\n", copies, title, author);
}

//return function is done in a similar manner
//I believe they could have been contained in one function, but that led to unexpected errors, so I stuck with them being separate
void return_book_fileIO(const char *fullname, const char *title, const char *author, int copies)
{
    FILE *file = fopen("books.csv", "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    FILE *temp_file = fopen("temp_books.csv", "w");
    if (temp_file == NULL) {
        perror("Error creating temporary file");
        fclose(file);
        return;
    }

    while (fgets(line, sizeof(line), file)) {
        char *token = strtok(line, ",");
        char *book_title = token;
        token = strtok(NULL, ",");
        char *book_author = token;
        token = strtok(NULL, ",");
        int available_copies = atoi(token);

        if (strcmp(book_title, title) == 0 && strcmp(book_author, author) == 0) {
            available_copies += copies;
        }

        fprintf(temp_file, "%s,%s,%d\n", book_title, book_author, available_copies);
    }

    fclose(file);
    fclose(temp_file);

    remove("books.csv");
    rename("temp_books.csv", "books.csv");

    printf("Successfully returned %d copies of \"%s\" by %s.\n", copies, title, author);

    FILE *loans_file = fopen("loans.csv", "r");
    if (loans_file == NULL) {
        perror("Error opening loans file");
        return;
    }

    FILE *temp_file2 = fopen("temp_loans.csv", "w");
    if (temp_file2 == NULL) {
        perror("Error creating temporary file");
        fclose(loans_file);
        return;
    }
    // copying the header
    char header[1024];
    if (fgets(header, sizeof(header), loans_file) != NULL) {
        fprintf(temp_file, "%s", header);
    } else {
        printf("Error: Unable to read header line.\n");
        fclose(loans_file);
        fclose(temp_file);
        remove("temp_loans.csv");
        return;
    }

    int book_removed = 0; // Flag to check if book is removed from loans.csv

    while (fgets(line, sizeof(line), loans_file)) {
        char *token = strtok(line, ",");
        char *borrower_name = token;
        token = strtok(NULL, ",");
        char *book_title = token;
        token = strtok(NULL, ",");
        char *book_author = token;
        token = strtok(NULL, ",");
        int borrowed_copies = atoi(token);

        if (strcmp(book_title, title) == 0 && strcmp(book_author, author) == 0) {
            borrowed_copies -= copies;
            if (borrowed_copies < 0) {
                printf("Error: Invalid number of copies to return.\n");
                fclose(loans_file);
                fclose(temp_file2);
                remove("temp_loans.csv");
                return;
            }
            // If borrowed_copies becomes 0, set the book_removed flag
            if (borrowed_copies == 0) {
                book_removed = 1;
            }
        }

        if (borrowed_copies != 0)
            fprintf(temp_file2, "%s,%s,%s,%d\n", borrower_name, book_title, book_author, borrowed_copies);
    }

    fclose(loans_file);
    fclose(temp_file2);

    remove("loans.csv");
    rename("temp_loans.csv", "loans.csv");

    if (book_removed)
        printf("Book \"%s\" by %s has been fully returned. Thank you for you cooperation\n", title, author);
}

void donate_book(char filename[], char title[], char author[], int copies)
{
    FILE *file = fopen(filename, "a");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    fprintf(file, "%s,%s,%d\n", title, author, copies);

    printf("Thank you for your contribution!\n");

    fclose(file);
}


void complex_search(char filename[], char query[])
{
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    while (fgets(line, sizeof(line), file)) {
        char *title = strtok(line, ",");
        char *author = strtok(NULL, ",");
        int copies = atoi(strtok(NULL, ","));

        remove_newline(title);
        remove_newline(author);

        char lowercase_title[256];
        char lowercase_author[256];
        strcpy(lowercase_title, title);
        strcpy(lowercase_author, author);
        to_lowercase(lowercase_title);
        to_lowercase(lowercase_author);

        // Here I split the given search query into words to be searched for
        char query_copy[256];
        strcpy(query_copy, query);
        char *word = strtok(query_copy, " ");
        int all_words_found = 1;
        while (word != NULL) {
            if (strstr(lowercase_title, word) == NULL && strstr(lowercase_author, word) == NULL) {
                all_words_found = 0;
                break;
            }
            word = strtok(NULL, " ");
        }

        if (all_words_found) {
            printf("Title: %s\nAuthor: %s\nCopies: %d\n\n", title, author, copies);
        }
    }

    fclose(file);
}

