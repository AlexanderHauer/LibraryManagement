#include "headers.h"
int main()
{
    int repeat = 1, choice;
    printf("Hello user!\n");
    login();
    printf("Welcome!\n");
    while(repeat==1)
    {
        printf("What would you like to do today?\n");
        printf("[1]Search for a book [2]Borrow [3]Return\n");
        printf("[4]View loans        [5]Donate [6]Exit\n");
        scanf("%d", &choice);
        switch(choice)
        {
        case 1:
            search_b();
            break;
        case 2:
            borrow();
            break;
        case 3:
            retur();
            break;
        case 4:
            loans();
            break;
        case 5:
            donate();
            break;
        case 6:
            repeat = 0;
            break;
        default:
            printf("Invalid choice\n");
        }
    }
    printf("Bye!\n");
    return 0;
}
